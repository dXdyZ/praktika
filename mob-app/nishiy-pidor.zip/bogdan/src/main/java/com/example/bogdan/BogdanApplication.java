package com.example.bogdan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BogdanApplication {

    public static void main(String[] args) {
        SpringApplication.run(BogdanApplication.class, args);
    }

}
